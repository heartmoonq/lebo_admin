/*
 * @Author: XiuJie_Lin xiujie_lin@lebo.cn
 * @Date: 2023-05-26 20:49:36
 * @LastEditors: XiuJie_Lin xiujie_lin@lebo.cn
 * @LastEditTime: 2023-05-27 10:42:26
 * @FilePath: \lebo_admin\src\utils\axios\index copy.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
