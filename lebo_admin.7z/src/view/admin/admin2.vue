
<template>
  <div>
    admin2
  </div>
</template>
  
<script setup lang='ts'>

</script>
  
<style></style>