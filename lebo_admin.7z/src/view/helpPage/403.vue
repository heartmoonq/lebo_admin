<template>
  <div>
    403
  </div>
</template>
  
<script setup lang='ts'>

</script>
  
<style></style>