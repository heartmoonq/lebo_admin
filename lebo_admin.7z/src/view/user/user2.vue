
<template>
  <div>
    user2
  </div>
</template>
  
<script setup lang='ts'>

</script>
  
<style></style>